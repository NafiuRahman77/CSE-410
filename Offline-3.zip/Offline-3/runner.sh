g++ *.cpp -o main -lglut -lGLU -lGL
./main